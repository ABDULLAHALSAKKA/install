echo -e "sutup ABDULLAH ALSAKKA "
pkg install mpv
termux-setup-storage
apt update -y
apt upgrade -y 
gem install lolcat
pkg install toilet -y
pkg install python -y
pkg install python2 -y
pkg install ruby -y
pkg install git -y
pkg install php -y
pkg  install proxychains
pkg install perl -y
pkg install nmap -y
pkg install bash -y
pkg install root-repo -y
pkg install unstable-repo -y
pkg install x11-repo -y
pkg install clang -y
pkg install macchanger -y
pkg install nano -y
pkg install figlet -y
pkg install cowsay -y
pkg install curl -y
pkg install tar -y
pkg install zip -y
pkg install unzip -y
pkg install tor -y
pkg install sudo -y
pkg install wget -y
pkg install wcalc -y
pkg install proot -y
pkg install openssl -y
pip2 install request
pip2 install mechanize
pip2 install requirements
pip install --upgrade pip
pkg install pip
pkg install nano
pip install mechanize
pip install --upgrade pip
pip2 install mechanize
pip install Browser
pip install --upgrade pip
pip2 install Browser
pip install --upgrade pip
pip2 install BeautifulSoup
pip install --upgrade pip
pip install BeautifulSoup
pip install --upgrade pip
pip install bs4
pip install --upgrade pip
pip2 install bs4
pip install --upgrade pip
pip install cookielib
pip install --upgrade pip
pip2 install cookielib
pip2 install --upgrade pip
pip2 install random
pip2 install --upgrade pip
pip2 install random
pip2 install mechanize
pip2 install requests
pip2 install requests
