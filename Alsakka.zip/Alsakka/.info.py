#!/usr/bin/jembod

import os, sys, time

def s():
	os.system('clear')
print('\033[1;33m')
def pres():
	print '\a'
	back = raw_input('intar   =====>  ')
	os.system('cd $HOME && cd Alsakka && python .Alsakka.py')

jembod = '\033[1;31m________________________________________\033[1;32m'
kontol = '\033[1;31m:\033[1;32m'

user = raw_input('[*] What is your name :')

s()
words = ('''\033[1;35m
Hello %s.
Welcome to Alsakka hack !
about:

Author     %s ABDULLAH ALSAKKA
updated    %s 2019-10-1 10:30
version    %s V.5.0
Total      %s 30 update 9 tools
facebook   %s https://www.facebook.com/Abdullah.Al.Sakka
youtube    %s https://www.youtube.com/channel/UCVaEEfPlGEnWEFzVN_62W1g
github     %s https://github.com/ABDULLAHALSAKKA
%s

Thanks for install and using
this tool ^_^
follow me on github and youtube to support me 
With greetings of Abdullah Al - Sakka 
Egyptian programmer :)

''' % (user, kontol, kontol, kontol, kontol, kontol, kontol, kontol, jembod,))
for char in words:
    time.sleep(0.1)
    sys.stdout.write(char)
    sys.stdout.flush()
pres()
