import sys, os, time

# Restart ####################
def restart_program():
   python = sys.executable
   os.execl(python, python, * sys.argv)
   curdir = os.getcwd()

 ##############################


os.system('clear')
os.system('''
toilet -f big 'ngrok' -F gay | lolcat ''')


print("\033[1;32m")
time.sleep(0.1)
print("")

print(" [1] tcp 8080              [4] http 8080")
time.sleep(0.1)
print(" [2] tcp 4444              [5] http 4444")
time.sleep(0.1)
print(" [3] tcp 80                [6] http 80")
time.sleep(0.1)
print(" [7] Download ngrok        [0] back")
time.sleep(0.1)
print("")
time.sleep(0.1)
print("")
time.sleep(0.1)
y=str(input("   \033[1;35m     number =======> "))



if y=="1":
  os.system("cd $HOME && ./ngrok tcp 8080")

elif y=="2":
        os.system("cd $HOME && ./ngrok tcp 4444")

elif y=="3":
        os.system("cd $HOME && ./ngrok tcp 80")

elif y=="5":
        os.system("cd $HOME && ./ngrok http 4444")

elif y=="4":
        os.system("cd $HOME && ./ngrok http 8088")

elif y=="6":
        os.system("cd $HOME && ./ngrok http 80")

elif y=="7":
        os.system('cp ngrok $HOME && termux-open-url https://dashboard.ngrok.com/')

elif y=="0":
        os.system("cd $H0ME && cd Alsakka && python .Alsakka.py")

else:
        print("\n\033[1;32m{+}\033[1;31m ERROR\033[1;39m ")
        time.sleep(1)
        restart_program()

