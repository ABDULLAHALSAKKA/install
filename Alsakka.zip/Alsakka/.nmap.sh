#!/usr/bin/bash
# AstraNmap v1.1
# Author: DedSecTL
# Date: 09-12-2017 (09:11)
# Github: http://github.com/Gameye98
# Blog: http://blackholesec.blogspot.com
# Team: BlackHole Security (BlackHoleSec)

p='\033[1;35m'
g='\033[1;32m'


if [ "$(which nmap)" == "" ]; then
	echo -n -e "nmap need to be installed [y/N] "
	read yorn
	if [ "$yorn" == "y" ] || [ "$yorn" == "Y" ]; then
		apt install nmap
	elif [ "$yorn" == "n" ] || [ "$yorn" == "N" ]; then
		exit
	else
		apt install nmap
	fi
fi
clear
toilet -f big '   nmap' -F gay | lolcat


echo -e '\033[1;35m(*)\033[1;31m Abdullah\033[1;33m Al Sakka'
echo
sleep 0.1
echo -e '\033[1;35m(*)\033[1;36m facebook :\033[1;32m https://www.facebook.com/aabdullah.Al.Sakka '
echo
sleep 0.1
echo -e '\033[1;35m(*)\033[1;36m github   :\033[1;33m https://github.com/ABDULLAHALSAKKA'
echo
sleep 0.1
echo -e '\033[1;35m(*)\033[1;36m gmail    :\033[1;34m aabdullah457010@gmail.com'




echo
echo
echo

echo
echo -e "\033[1;32m[1] Scan IP"
sleep 0.1
echo -e "[2] Scan multiple ip subnet"
sleep 0.1
echo -e "[3] Read list networks file"
sleep 0.1
echo -e "[4] OS and version detection scan"
sleep 0.1
echo -e "[5] Scan a host when protected by the firewall"
sleep 0.1
echo -e "[6] Scan an IPv6 host/address"
sleep 0.1
echo -e "[7] Only show open (or possibly open) ports"
sleep 0.1
echo -e "[8] Show all packets sent and received"
sleep 0.1
echo -e "[9] Fast scan all your devices/computers for open ports ever"
sleep 0.1
echo -e "[0] back"
sleep 0.1
echo
echo
echo
sleep 0.1
echo
sleep 0.1
echo
sleep 0.1
echo -n -e "       \033[1;35m         • Enter number•======> "

read astranmap

if [ "$astranmap" == "01" ] || [ "$astranmap" == "1" ];
then
echo
echo -n -e "Enter ( IP ): "
read iphostname
echo
nmap $iphostname

elif [ "$astranmap" == "02" ] || [ "$astranmap" == "2" ];
then
echo
echo -n -e "Enter ( IP ): "
read iphostname
for lulz in $iphostname
do
  echo
  nmap $lulz
done

elif [ "$astranmap" == "03" ] || [ "$astranmap" == "3" ];
then
echo
echo -n -e "Enter File: "
read txtfile
echo
nmap -iL $txtfile

elif [ "$astranmap" == "04" ] || [ "$astranmap" == "4" ];
then
echo
echo -n -e "Enter ( IP ): "
read iphostname
echo
nmap -A $iphostname

elif [ "$astranmap" == "05" ] || [ "$astranmap" == "5" ];
then
echo
echo -n -e "Enter ( IP ): "
read iphostname
echo
nmap -PN $iphostname

elif [ "$astranmap" == "06" ] || [ "$astranmap" == "6" ];
then
echo
echo -n -e " IPv6-Address: "
read ipvsixaddress
echo
nmap -6 $ipvsixaddress

elif [ "$astranmap" == "07" ] || [ "$astranmap" == "7" ];
then
echo
echo -n -e "Enter ( IP ): "
read iphostname
echo
nmap --open $iphostname

elif [ "$astranmap" == "08" ] || [ "$astranmap" == "8" ];
then
echo
echo -n -e "Enter ( IP ): "
read iphostname
echo
nmap --packet-trace $iphostname

elif [ "$astranmap" == "09" ] || [ "$astranmap" == "9" ];
then
echo
echo -n -e "Enter ( IP ): "
read iphostname
echo
nmap -T5 $iphostname

elif [ "$astranmap" == "00" ] || [ "$astranmap" == "0" ];
then
cd $HOME && cd Alsakka && python .Alsakka.py

else
echo
echo -e "\033[1;31m[!] ERROR\033[1;0m"
sleep 1
bash $0
fi
